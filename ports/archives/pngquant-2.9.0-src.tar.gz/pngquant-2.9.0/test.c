int test(int x) {
    if (x > 0) {
        return 1;
    }
}
